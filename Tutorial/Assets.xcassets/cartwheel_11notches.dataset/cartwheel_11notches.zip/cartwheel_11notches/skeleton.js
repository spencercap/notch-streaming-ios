{
    "skeleton": [
        {
            "name": "Root",
            "mass_ratio": 0,
            "end_offset": [
                0,
                0,
                0
            ],
            "parent_name": "Root",
            "offset": [
                0,
                0,
                0
            ]
        },
        {
            "name": "Hip",
            "mass_ratio": 0,
            "end_offset": [
                0,
                0,
                0
            ],
            "parent_name": "Root",
            "offset": [
                0,
                0,
                0
            ]
        },
        {
            "name": "Tummy",
            "mass_ratio": 0,
            "end_offset": [
                0,
                0,
                0
            ],
            "parent_name": "Hip",
            "offset": [
                0,
                0.04,
                0
            ]
        },
        {
            "name": "ChestBottom",
            "mass_ratio": 0,
            "end_offset": [
                0,
                0,
                0
            ],
            "parent_name": "Tummy",
            "offset": [
                0,
                0.194,
                0
            ]
        },
        {
            "name": "ChestTop",
            "mass_ratio": 0,
            "end_offset": [
                0,
                0,
                0
            ],
            "parent_name": "ChestBottom",
            "offset": [
                0,
                0.166,
                0
            ]
        },
        {
            "name": "LeftCollar",
            "mass_ratio": 0,
            "end_offset": [
                0,
                0,
                0
            ],
            "parent_name": "ChestTop",
            "offset": [
                0,
                0.1,
                0
            ]
        },
        {
            "name": "LeftUpperArm",
            "mass_ratio": 0,
            "end_offset": [
                0,
                0,
                0
            ],
            "parent_name": "LeftCollar",
            "offset": [
                0.156,
                -0.02,
                0
            ]
        },
        {
            "name": "LeftForeArm",
            "mass_ratio": 0,
            "end_offset": [
                0,
                0,
                0
            ],
            "parent_name": "LeftUpperArm",
            "offset": [
                0.026,
                -0.255,
                0
            ]
        },
        {
            "name": "LeftHand",
            "mass_ratio": 0,
            "end_offset": [
                0,
                -0.15,
                0
            ],
            "parent_name": "LeftForeArm",
            "offset": [
                0.0065,
                -0.311,
                0
            ]
        },
        {
            "name": "RightCollar",
            "mass_ratio": 0,
            "end_offset": [
                0,
                0,
                0
            ],
            "parent_name": "ChestTop",
            "offset": [
                0,
                0.1,
                0
            ]
        },
        {
            "name": "RightUpperArm",
            "mass_ratio": 0,
            "end_offset": [
                0,
                0,
                0
            ],
            "parent_name": "RightCollar",
            "offset": [
                -0.156,
                -0.02,
                0
            ]
        },
        {
            "name": "RightForeArm",
            "mass_ratio": 0,
            "end_offset": [
                0,
                0,
                0
            ],
            "parent_name": "RightUpperArm",
            "offset": [
                -0.026,
                -0.255,
                0
            ]
        },
        {
            "name": "RightHand",
            "mass_ratio": 0,
            "end_offset": [
                0,
                -0.15,
                0
            ],
            "parent_name": "RightForeArm",
            "offset": [
                -0.0065,
                -0.311,
                0
            ]
        },
        {
            "name": "Neck",
            "mass_ratio": 0,
            "end_offset": [
                0,
                0,
                0
            ],
            "parent_name": "ChestTop",
            "offset": [
                0,
                0.1,
                0
            ]
        },
        {
            "name": "Head",
            "mass_ratio": 0,
            "end_offset": [
                0,
                0.127,
                0.0156
            ],
            "parent_name": "Neck",
            "offset": [
                0,
                0.127,
                0
            ]
        },
        {
            "name": "LeftHip",
            "mass_ratio": 0,
            "end_offset": [
                0,
                0,
                0
            ],
            "parent_name": "Root",
            "offset": [
                0,
                0,
                0
            ]
        },
        {
            "name": "LeftThigh",
            "mass_ratio": 0,
            "end_offset": [
                0,
                0,
                0
            ],
            "parent_name": "LeftHip",
            "offset": [
                0.088,
                -0.02,
                0
            ]
        },
        {
            "name": "LeftLowerLeg",
            "mass_ratio": 0,
            "end_offset": [
                0,
                0,
                0
            ],
            "parent_name": "LeftThigh",
            "offset": [
                0,
                -0.422,
                0
            ]
        },
        {
            "name": "LeftFootTop",
            "mass_ratio": 0,
            "end_offset": [
                0,
                0,
                0
            ],
            "parent_name": "LeftLowerLeg",
            "offset": [
                0,
                -0.443,
                0
            ]
        },
        {
            "name": "LeftFootFront",
            "mass_ratio": 0,
            "end_offset": [
                0,
                -0.0345,
                0.0931
            ],
            "parent_name": "LeftFootTop",
            "offset": [
                0,
                -0.04,
                0.1047
            ]
        },
        {
            "name": "RightHip",
            "mass_ratio": 0,
            "end_offset": [
                0,
                0,
                0
            ],
            "parent_name": "Root",
            "offset": [
                0,
                0,
                0
            ]
        },
        {
            "name": "RightThigh",
            "mass_ratio": 0,
            "end_offset": [
                0,
                0,
                0
            ],
            "parent_name": "RightHip",
            "offset": [
                -0.088,
                -0.02,
                0
            ]
        },
        {
            "name": "RightLowerLeg",
            "mass_ratio": 0,
            "end_offset": [
                0,
                0,
                0
            ],
            "parent_name": "RightThigh",
            "offset": [
                0,
                -0.422,
                0
            ]
        },
        {
            "name": "RightFootTop",
            "mass_ratio": 0,
            "end_offset": [
                0,
                0,
                0
            ],
            "parent_name": "RightLowerLeg",
            "offset": [
                0,
                -0.443,
                0
            ]
        },
        {
            "name": "RightFootFront",
            "mass_ratio": 0,
            "end_offset": [
                0,
                -0.0345,
                0.0931
            ],
            "parent_name": "RightFootTop",
            "offset": [
                0,
                -0.04,
                0.1047
            ]
        }
    ]
}