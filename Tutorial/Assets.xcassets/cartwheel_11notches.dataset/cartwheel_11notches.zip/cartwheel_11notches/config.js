{
    "highlighted_bones": [
        "LeftForeArm",
        "LeftLowerLeg",
        "Hip",
        "RightUpperArm",
        "RightThigh",
        "LeftThigh",
        "Head",
        "LeftUpperArm",
        "RightForeArm",
        "ChestTop",
        "RightLowerLeg"
    ],
    "obj_groups": {},
    "disabled_bones": [],
    "custom":
	{
		"sharing_url" : "https://wearnotch.com/m/2XDAI3SQQJSeCkfYQ5rCEw/",
		"measurement_name" : "Cartwheel",
		"workout_name" : "Example",
		"notch_count" : 11
	}
}
